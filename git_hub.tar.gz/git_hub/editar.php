<?php require_once('redirect.php');?>
<?php require_once 'header.php';?>
<?php
$id = $_GET['id'];

    if(!isset($id) || empty($id) || !is_numeric($id)){
        header("Location:index_.php");
    }

 $sql = "select * from users where users_id = '" . $id . "'";
 $query = mysqli_query($db,$sql);
 $user = mysqli_fetch_assoc($query);

if(!isset($user['users_id']) || empty($user['users_id'])){
    header("Location:index_.php");
}


function showErrors($errors,$field){
        if (isset($errors[$field]) && !empty($field)) {
        $alert = '<div class="alert alert-danger">' . $errors[$field] . '</div>';
        }else{
            $alert = "";
        }
        return $alert;
}

function setValuesField($data,$field,$textarea = false){
    if(isset($data) && count($data) >= 1){
        if($textarea != false){
            echo $data[$field];
        }else{
            echo "value='{$data[$field]}'";
        }
        //echo "value='{$_POST[$field]}'";
    }
}

$errors = array();

    if (isset($_POST["submit"])) {

        if (!empty($_POST['name']) && strlen($_POST['name']) <= 20
            && !is_numeric($_POST['name']) && !preg_match("/[0-9]/",$_POST['name'])) {

            $name_validate = true;
        }else{
            $name_validate = false;
            $errors['name'] = "El nombre no es valido";
        }

        if (!empty($_POST['surname']) && !is_numeric($_POST['surname'])
            && !preg_match("/[0-9]/",$_POST['surname'])) {

            $surname_validate = true;
        }else{
            $surname_validate = false;
            $errors['surname'] = "El apellido no es valido";
        }

        if (!empty($_POST['bio'])) {
            $bio_validate = true;
        }else{
            $bio_validate = false;
            $errors['bio'] = "Biografia no puede estar vacia";
        }

        if (!empty($_POST['email']) && filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)) {
            $email_validate = true;
        }else{
            $email_validate = false;
            $errors['email'] = "Ingresa un email valido";
        }

        /*if (!empty($_POST['password']) && strlen($_POST['password']) >= 6) {
            $password_validate = true;
        }else{
            $password_validate = false;
            $errors['password'] = "Ingrsa una contraseña de mas de 6 caracteres";
        }*/

        if (is_numeric($_POST['role']) && isset($_POST['role'])) {
            $role_validate = true;
        }else{
            $role_validate = false;
            $errors['role'] = "Seleciona un rol";
        }


        $image = null;
        if (isset($_FILES['image']) && !empty($_FILES['image']['tmp_name'])) {

            if (!is_dir("uploads")) {
                $dir = mkdir('uploads',0777,true);
            }else{
                $dir = true;
            }

            if($dir){
                $filename = time()."_".$_FILES['image']['name'];
                $muf = move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$filename);

            $image = $filename;

            if ($muf) {
                $image_upload = true;
            }else{
                $image_upload = false;
                $errors['image'] = "La imagen no se subio";
            }

          }
        }

        // Update usuario en la BD
    if(count($errors)==0){
        $sql = "UPDATE users set name = '{$_POST["name"]}', "
        . "surname = '{$_POST["surname"]}', "
        . "bio = '{$_POST["bio"]}', "
        . "email = '{$_POST["email"]}', ";

        if(isset($_POST["password"]) && !empty($_POST["password"])){
            $sql.= "password = '".sha1($_POST["password"])."', ";
        }

        if(isset($_FILES["image"]) && !empty($_FILES["image"]["tmp_name"])){
            $sql.= "image = '{$image}', ";
        }

        $sql.= "role = '{$_POST["role"]}' WHERE users_id = {$user["users_id"]};";
        //echo $sql;
        //die();
        $update_user = mysqli_query($db, $sql);

        if($update_user){
            $user_query = mysqli_query($db, "SELECT * FROM users WHERE users_id = {$id}");
            $user = mysqli_fetch_assoc($user_query);
        }

    }else{
        $update_user = false;
    }

}

?>
<h2>Editar Usuario: <?php echo $id . " - " . $user['name']. " " . $user['surname'];?></h2>
<?php
    if (count($errors) == 0 && isset($_POST["submit"]) && $update_user != false) {
    ?>
    <div class="alert alert-success">
        El usuario se ha agregado correctamente.
    </div>
    <?php
    }elseif(isset($_POST["submit"])){
      ?>
        <div class="alert alert-danger">
        El usuario NO se ha agregado correctamente.
    </div>
<?php
    }
?>
<form action="" method="POST" enctype="multipart/form-data">
    <label for="name">
    Nombre:
    <input type="text" name="name" class="form-control" <?php setValuesField($user,"name");?> />
        <?php echo showErrors($errors,'name')?>
    </label>
    <br/>
    <label for="surname">
    Apellido
    <input type="text" name="surname" class="form-control" <?php setValuesField($user,"surname");?> />
    <?php echo showErrors($errors,'surname')?>
    </label>
    <br/>
    <label for="bio">
    Biografia:
    <textarea name="bio" class="form-control" /><?php setValuesField($user,"bio",true);?></textarea>
    <?php echo showErrors($errors,'bio')?>
    </label>
    <br/>
    <label for="email">
    Correo:
    <input type="email" name="email" class="form-control" <?php setValuesField($user,"email");?>/>
    <?php echo showErrors($errors,'email')?>
    </label>
    <br/>
    <label for="image" >
    <?php if ($user['image'] != null ){?>
    Imagen:<img src="uploads/<?php echo $user['image'];?>" width="110" height="110" />
    <?php }?>
    Actualizar imagen:
    <input type="file" name="image" class="form-control" />
    </label>
    <br/>
    <label for="password">
    Contraseña:
    <input type="password" name="password" class="form-control" />
    <?php echo showErrors($errors,'password')?>
    </label>
    <br/>
    <label for="role">
    Rol:
    <select name="role" class="form-control">
        <option value="0" <?php if($user['role'] == 0){echo "selected='selected'";}?>>Normal</option>
        <option value="1" <?php if($user['role'] == 1){echo "selected='selected'";}?>>Administrador</option>
    </select>
    </label>
    <br/>
    <input type="submit" value="Enviar" name="submit" class="btn btn-success" />
</form>
<?php require_once 'footer.php';?>