<?php require_once('redirect.php');?>
<?php
require_once('header.php');
$id = $_GET['id'];

 //echo $id = $_GET['id'];

//echo $id;

    if(!isset($id) || empty($id) || !is_numeric($id)){
        header("Location:index_.php");
    }

 $sql = "SELECT * FROM users WHERE users_id = '" . $id . "'";
 $query = mysqli_query($db,$sql);
 $user = mysqli_fetch_assoc($query);

if(!isset($user['users_id']) || empty($user['users_id'])){
    header("Location:index_.php");
}

?>
        <?php if($user['image'] != null){?>
            <br/><br/>
            <img src="uploads/<?php echo $user['image'];?>" width="110" height="110" />
        <?php }?>
        <h3>Usuario: <?php echo $user['name'] . " " . $user['surname'] ?></h3>
        <p>Correo: <?php echo $user['email'];?></p>
        <p>Biografia: <?php echo $user['bio'];?></p>
    <div class="clearfix"></div>
    <!--<a href="index_.php" class="btn btn-success">Volver</a>-->
<?php require_once('footer.php');?>