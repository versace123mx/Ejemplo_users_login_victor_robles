<?php
    require_once('connect_db.php');

$sql = "INSERT INTO users VALUES (null,'Tiffany','Alvord','Cantante de Youtube','tiffanyalvord@gmail.com','".sha1('password')."','1','tiffany.jpg')";
$add_registrert = mysqli_query($db,$sql);


$sql = "INSERT INTO users VALUES (null,'Gustavo','Marchena','Huaker PengoStores','huaker@gmail.com','".sha1('sdf54s8w7e')."','1','huaker.jpg')";
$add_registrert1 = mysqli_query($db,$sql);


$sql = "INSERT INTO users VALUES (null,'Jose','Carlos','Muy buen amigo','papyparcker@gmail.com','".sha1('4fre7t8te7')."','1','parcker.jpg')";
$add_registrert2 = mysqli_query($db,$sql);


$sql = "INSERT INTO users VALUES (null,'Luis','Castro','Youtube','luisC@gmail.com','".sha1('sfsdfsdsdds45r7tfgf')."','1','holasdsad.jpg')";

$add_registrert3 = mysqli_query($db,$sql);


//echo mysqli_error(db);


if ($add_registrert) {
    echo "Se ingresaron datos correctamente";
}
?>