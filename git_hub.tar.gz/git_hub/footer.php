<hr/>
<footer>
    &copy; Gustavo Marchena <?php echo date("Y ")?><?php echo $variable; ?>
</footer>
</div>
</body>
</html>