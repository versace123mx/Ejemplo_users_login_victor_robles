<?php
    require_once('redirect.php');
    require_once 'header.php';
    $users = mysqli_query($db,"SELECT * FROM users");

    //Paginacion
    $num_users_total = mysqli_num_rows($users);

    if ($num_users_total > 0) {
        $rows_per_page = 3;
        $page = false;

        if (isset($_GET['page'])) {
            $page = $_GET['page'];
        }

        if (!$page) {
            $start = 0;
            $page = 1;
        }else{
            $start = ($page - 1) * $rows_per_page;
        }

        $total_page = ceil($num_users_total / $rows_per_page);

        $sql = "SELECT * FROM users ORDER BY users_id DESC LIMIT {$start},{$rows_per_page} ";
        $users = mysqli_query($db,$sql);

    }else{
        echo "No hay usuarios";
    }

?>
<table class="table">
        <tr>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Ver/Editar</th>
        </tr>
        <?php
            while ($row = mysqli_fetch_assoc($users)) {
        ?>
        <tr>
            <td><?php echo $row['name']?></td>
            <td><?php echo $row['surname']?></td>
            <td><?php echo $row['email']?></td>
            <td><a class="btn btn-success" href="ver.php?id=<?php echo $row['users_id'];?>">Ver</a>

            <?php
                if (isset($_SESSION['logged']) && $_SESSION['logged']['role'] == 1) {
            ?>
            <a class="btn btn-warning" href="editar.php?id=<?php echo $row['users_id']?>">Editar</a>
            <?php }?>
            <?php if(isset($_SESSION['logged']) && $_SESSION['logged']['role'] == 1){?>
                <a class="btn btn-danger" href="borrar.php?id=<?php echo $row['users_id']?>">Borrar</a>
            <?php } ?>
            </td>
        </tr>
        <?php
            }
        ?>
</table>
<?php if ($num_users_total > 0) { ?>
    <ul class="pagination">
        <li><a href="?page=<?php echo $page - 1;?>"><<</a></li>
            <?php for ($i=1; $i <= $total_page; $i++) { ?>

                <?php if($page == $i) {?>

                    <li class="disabled"><a href="#"><?php echo $i;?></a></li>

                <?php }else{?>

                        <li><a href="?page=<?php echo $i;?>"><?php echo $i;?></a></li>

                    <?php } ?>

            <?php }?>
        <li><a href="?page=<?php $show_page = $page + 1; if ($show_page <= $total_page){echo $page + 1;}else{echo $total_page; }?> "> >> </a></li>
    </ul>
<?php } ?>
<?php
    require_once 'footer.php';
?>