<?php
    //Inicio de secion
    //session_start();

    //Conexion
    //
    $db = new mysqli('localhost','root','root','cursophp');
    //$db->query(); esta query es para POO
    $sql = "SET NAMES 'utf-8'";
    mysqli_query($db,$sql);
?>