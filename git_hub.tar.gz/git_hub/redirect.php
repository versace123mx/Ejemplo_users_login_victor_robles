<?php
// Inicio sesiones
session_start();
//var_dump($_SESSION);
//die();

if(!isset($_SESSION["logged"])){
	header("Location: login.php");
}
?>

