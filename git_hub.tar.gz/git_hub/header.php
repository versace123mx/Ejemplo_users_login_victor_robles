<?php require_once('connect_db.php'); ?>
<!DOCTYPE html>
<html>
<head lang="es">
<meta charset="utf-8">
    <title>Web con PHP</title>
    <link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap-theme.css">
    <script type="text/javascript" src="js/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>
<div class="container">
    <h1>Web con PHP</h1>
    <hr/>
    <?php if(isset($_SESSION['logged'])){?>
        <div class="col-lg-8">
        <?php
                if (isset($_SESSION['logged']) && $_SESSION['logged']['role'] == 1) {
            ?>
        <a href="crear.php" class="btn btn-primary">Crear Nuevo Usuario</a>
        <?php } ?>
        <a href="index_.php" class="btn btn-success">Regresar</a>
        </div>
        <div class="col-lg-4">
            <h5><?php echo "Bienvenido " . $_SESSION['logged']['name']." ".$_SESSION['logged']['surname']?></h5>
            <br/>
            <a href="logout.php" class="btn btn-primary col-lg-7">Logout</a>
        </div>
        <div class="clearfix"></div>
        <hr/>
     <?php }?>
    <?php $variable = "Contenido"; ?>