<?php
    require_once('connect_db.php');
$sql ="create table IF NOT EXISTS users(
        users_id int(255) auto_increment not null,
        name varchar(255),
        surname varchar(255),
        bio   text,
        email       varchar(255),
        password    varchar(255),
        role         varchar(20),
        image       varchar(255),
        CONSTRAINT pk_users PRIMARY KEY(users_id)
);";

$create_usuarios_table = mysqli_query($db,$sql);

if ($create_usuarios_table) {
    echo "Se creo la tabla correctamente";
}
?>