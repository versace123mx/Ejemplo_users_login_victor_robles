<?php
session_start();

if(!isset($_SESSION["logged"]) && $_SESSION['logged']['role'] == 1){
    require_once('connect_db.php');
    
    if (isset($_GET['id'])) {
        $id=$_GET['id'];
        $sql="DELETE FROM users WHERE users_id = '".$id."'";
        $delete = mysqli_query($db,$sql);
    }
}

header("Location: index_.php");
?>