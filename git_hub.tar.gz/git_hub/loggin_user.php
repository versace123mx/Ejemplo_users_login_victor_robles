<?php
session_start();
?>
<?php require_once('connect_db.php'); ?>
<?php
    if (isset($_POST['submit'])) {
        //var_dump($_POST);
        //
        $email = trim($_POST['email']);
        $password = sha1($_POST['password']);

        $sql = "SELECT * FROM users WHERE email = '{$email}' AND password = '{$password}'";
        $login = mysqli_query($db,$sql);

        if ($login && mysqli_num_rows($login) == 1) {

            $_SESSION['logged'] = mysqli_fetch_assoc($login);

            if (isset($_SESSION['error_login'])) {
                unset($_SESSION['error_login']);
            }

            header('Location:index_.php');

        }else{

            $_SESSION['error_login'] = "Login incorrecto!!";

        }
    }
    header('Location:login.php');
?>