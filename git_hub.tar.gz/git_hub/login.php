<?php
session_start();

if(isset($_SESSION["logged"])){
    header("Location: index_.php");
}
?>
<?php require_once 'header.php';?>
<h2>Identificate</h2>
<div class="col-lg-3">
<?php
    //var_dump($_SESSION);
?>
<?php if(isset($_SESSION['error_login'])){?>
<div class="alert alert-danger"><?php echo $_SESSION['error_login'];?></div>
<?php } ?>
<form action="loggin_user.php" method="POST">
Email:<input type="email" name="email" class="form-control" />
Password:<input type="password" name="password" class="form-control" />
<br/>
<input type="submit" class="btn btn-success" name="submit" value="Entrar">
</form>
</div>
<div class="clearfix"></div>
<?php require_once 'footer.php';?>